SET CONCAT OFF;
SET DEFINE &;
DEFINE hr=hr;
DEFINE hr_test=hr_test;
