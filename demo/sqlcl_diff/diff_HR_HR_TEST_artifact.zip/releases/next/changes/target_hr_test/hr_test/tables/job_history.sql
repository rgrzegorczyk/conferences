/*  Uncomment drop statement after ensuring it is performing the correct actions
ALTER TABLE "HR"."JOB_HISTORY" DROP ("TEST")
/
*/

