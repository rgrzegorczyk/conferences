--stage
@@hr_test/tables/job_history.sql
